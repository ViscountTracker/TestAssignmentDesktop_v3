﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.
// script.js

// Function to fetch and display the top currencies
async function getTopCurrencies() {
    try {
        const response = await fetch('/api/cryptocurrency/getTopCurrencies');
        const currencies = await response.json();

        // Display the currencies in the top-currencies section
        const topCurrenciesSection = document.getElementById('top-currencies');
        topCurrenciesSection.innerHTML = '';

        currencies.forEach(currency => {
            const currencyElement = document.createElement('div');
            currencyElement.classList.add('currency');
            currencyElement.innerHTML = `
        <h3>${currency.name}</h3>
        <p>Symbol: ${currency.symbol}</p>
        <p>Price: ${currency.currentPrice}</p>
        <p>Market Cap: ${currency.marketCap}</p>
        <p>Price Change (24h): ${currency.priceChangePercentage24h}%</p>
      `;
            topCurrenciesSection.appendChild(currencyElement);
        });
    } catch (error) {
        console.log('An error occurred while fetching top currencies:', error);
    }
}

// Function to fetch and display currency details
async function getCurrencyDetails(currencyId) {
    try {
        const response = await fetch(`/api/cryptocurrency/getCurrencyDetails/${currencyId}`);
        const currency = await response.json();

        // Display the currency details in the currency-details section
        const currencyDetailsSection = document.getElementById('currency-details');
        currencyDetailsSection.innerHTML = '';

        const currencyElement = document.createElement('div');
        currencyElement.classList.add('currency-details');
        currencyElement.innerHTML = `
      <h3>${currency.name}</h3>
      <p>Symbol: ${currency.symbol}</p>
      <p>Price: ${currency.currentPrice}</p>
      <p>Market Cap: ${currency.marketCap}</p>
      <p>Price Change (24h): ${currency.priceChangePercentage24h}%</p>
      <h4>Markets:</h4>
      <ul>
        ${currency.markets.map(market => `<li>${market}</li>`).join('')}
      </ul>
    `;
        currencyDetailsSection.appendChild(currencyElement);
    } catch (error) {
        console.log('An error occurred while fetching currency details:', error);
    }
}

// Function to fetch and display the quote chart
async function getQuoteChart(currencyId) {
    try {
        const response = await fetch(`/api/cryptocurrency/getQuoteChart/${currencyId}`);
        const chartData = await response.json();

        // Extract date and price data for the chart
        const dates = chartData.map(dataPoint => new Date(dataPoint.date));
        const prices = chartData.map(dataPoint => dataPoint.price);

        // Render the chart using Chart.js library
        const chartCanvas = document.getElementById('chart');
        const ctx = chartCanvas.getContext('2d');

        new Chart(ctx, {
            type: 'line',
            data: {
                labels: dates,
                datasets: [{
                    label: 'Price',
                    data: prices,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    } catch (error) {
        console.log('An error occurred while fetching quote chart:', error);
    }
}
