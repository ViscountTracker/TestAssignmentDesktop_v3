﻿using Microsoft.AspNetCore.Mvc;
using System.Net;
using TestAssignmentDesktop_v3.Models;
using static System.Net.WebRequestMethods;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;
using System.Reflection.PortableExecutable;
using System.Collections;

namespace TestAssignmentDesktop_v3.Controllers
{
    public class HomeController : Controller
    {
        [ApiController]
        [Route("api/[controller]")]
        public class CryptocurrenceController : Controller
        {
            private readonly string apiUrl = "https://coinmarketcap.com/trending-cryptocurrencies/";
          //private readonly string apiKey = "9422cac3-d863-4e2f-83da-d93020511183";
        }
        //Method for obtaining top cryptocurrencies
        [HttpGet]
        public async Task<IActionResult> GetTopCurrencies(int count = 10) 
        {
            try
            {
                var endpoint = $"coins/markets?vs_currency=usd&order=market_cap_desc&per_page={count}&page=1";
                var currency = await MakeApiRequest<List<Currency>>(endpoint); 
                return Ok(currency);
            }
            catch (Exception ex)
            { //Logging errors
                Console.WriteLine($"An error occured: {ex.Message}");
                return StatusCode(500, "An error occured while fitching top currencies.");
            }
        }
        // Method for obtaining detailed cryptocurrency information by identifier
        [HttpGet("{Id}")]
        public async Task<IActionResult> GetCurrenciesDetails(string id) 
        {
            try
            {
                var endpoint = $"Coins/{id}";
                var currency = await MakeApiRequest<Currency>(endpoint);
                return Ok(currency);
            }
            catch (Exception ex)
            {//Logging errors
                Console.WriteLine($"An error occurred: {ex.Message}");
                return StatusCode(500, "An error occurred while fetching currency details.");
            }
        }

        // Auxiliary method for executing HTTP requests to API
        private async Task<T> MakeApiRequest<T>(string endpoint) 
        {
            var request = WebRequest.Create($"{apiUrl}/{endpoint}");//TODO: Fix this path of code
            request.Method = "GET";

            using (var response = await request.GetResponseAsync());
            using (var stream = response.GetResponseStream()) ;//TODO: Fix this path of code
            using (var reader = new StreamReader(stream)) ;//TODO: Fix this path of code
            {
                var content = await reader.ReadToEndAsync();//TODO: Fix this path of code
                var result = JsonSerializer.Deserialize<T>(content);
                return result;
            }
        }


        public class Currency
        {
            public string Id { get; set; }
            public string Name { get; set; }
            public string Symbol { get; set; }
            public decimal CurrentPrice { get; set; }
            public decimal MarketCap { get; set; }
            public decimal PriceChangePercentage24h { get; set; }
            public string[] Markets { get; set; }
        }
        // Presentation model for detailed cryptocurrency information
        public class CurrencyDetailsViewModel
        {
            public string Id { get; set; }
            public string Name { get; set; }
            public string Symbol { get; set; }
            public decimal CurrentPrice { get; set; }
            public decimal MarketCap { get; set; }
            public decimal PriceChangePercenttage24h { get; set; }
            public string[] Markets { get; set; }
            public string Description { get; set; }
            public string Image { get; set; }
            public string Homepage { get; set; }
            public string[] Sparkline { get; set; }
        }
        // Method for searching cryptocurrency by name or symbol
        [HttpGet("search")]
        public async Task<IActionResult> SearchCurrency(string query)
        {
            try
            {
                var endpoint = $"coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false&ids={query}";
                var currencies = await MakeApiRequest<List<Currency>>(endpoint);
                return Ok(currencies);
            }
            catch (Exception ex)
            {
                //Logging error
                Console.WriteLine($"An error occurred: {ex.Message}");
                return StatusCode(500, "An error occurred while searching for currencies.");
                throw;
            }
        }
        // Method for converting one currency into another
        [HttpGet("convert")]
        public async Task<IActionResult> ConvertCurrency(string from, string to, decimal amount)
        {
            try
            {
                var endpoint = $"simple/price?ids={from}&vs_currencies={to}&amount={amount}";
                var result = await MakeApiRequest<Dictionary<string, Dictionary<string, decimal>>>(endpoint);
                if (result.TryGetValue(from, out var conversionData) && conversionData.TryGetValue(to, out var convertedAmount))
                {
                    var conversionResult = new
                    {
                        FromCurrency = from,
                        ToCurrency = to,
                        Amount = amount,
                        ConvertedAmount = convertedAmount
                    };
                    return Ok(conversionResult);
                }
                return BadRequest("Unable to perform currency conversion.");
            }
            catch (Exception ex)
            {
                // Logging errors
                Console.WriteLine($"An error occurred: {ex.Message}");
                return StatusCode(500, "An error occurred while converting currencies.");
            }
        }
        // Presentation Model for Quotation Chart
        public class QuoteChart
        {
            public List<long> Timestamps { get; set; }
            public QuoteChartData Prices { get; set; }
        }

        // Presentation model for price chart data
        public class QuoteChartData
        {
            public List<decimal> USD { get; set; }
        }
    }
}